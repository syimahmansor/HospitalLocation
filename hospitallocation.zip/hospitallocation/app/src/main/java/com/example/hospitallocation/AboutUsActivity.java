package com.example.hospitallocation;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AboutUsActivity extends AppCompatActivity {

    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // Set up the back button
        backButton = findViewById(R.id.btnBackToHome);
        backButton.setOnClickListener(view -> {
            // Retrieve the user email from the intent
            String userEmail = getIntent().getStringExtra("userEmail");

            // Go back to HomeActivity and pass the user email
            Intent intent = new Intent(AboutUsActivity.this, HomeActivity.class);
            intent.putExtra("userEmail", userEmail);  // Pass the email back to HomeActivity
            startActivity(intent);
            finish();  // Finish the AboutUsActivity
        });
    }
}
