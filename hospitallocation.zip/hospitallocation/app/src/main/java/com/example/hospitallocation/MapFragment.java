package com.example.hospitallocation;

import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;

public class MapFragment extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap googleMap;

    @Override
    public void onMapReady(GoogleMap googleMap) {

    }
}

