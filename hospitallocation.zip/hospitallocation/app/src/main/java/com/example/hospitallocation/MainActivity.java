package com.example.hospitallocation;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.FirebaseApp;


public class MainActivity extends AppCompatActivity {

    // Firebase instances
    private FirebaseAuth auth;
    private DatabaseReference database;

    // UI elements
    private EditText emailEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button registerButton;
    private TextView greetingTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Make sure this layout exists and matches your project

        try {
            // Initialize Firebase and UI components
            auth = FirebaseAuth.getInstance();
            database = FirebaseDatabase.getInstance().getReference();

            Log.d("Firebase", "Firebase initialized: " + FirebaseApp.getApps(this).isEmpty());

            emailEditText = findViewById(R.id.etEmail);
            passwordEditText = findViewById(R.id.etPassword);
            loginButton = findViewById(R.id.btnLogin);
            registerButton = findViewById(R.id.btnRegister);
            greetingTextView = findViewById(R.id.tvWelcome);

            // Handle login button click
            loginButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("MainActivity", "Login button clicked");
                    String email = emailEditText.getText().toString().trim();
                    String password = passwordEditText.getText().toString().trim();

                    if (email.isEmpty() || password.isEmpty()) {
                        Toast.makeText(MainActivity.this, "Please fill out all fields.", Toast.LENGTH_SHORT).show();
                    } else {
                        loginUser(email, password);
                    }
                }
            });
            registerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String email = emailEditText.getText().toString().trim();
                    String password = passwordEditText.getText().toString().trim();

                    if (email.isEmpty() || password.isEmpty()) {
                        Toast.makeText(MainActivity.this, "Please fill out all fields.", Toast.LENGTH_SHORT).show();
                    } else {
                        registerUser(email, password);
                    }
                }
            });
        } catch (Exception e) {
            Log.e("MainActivity", "Error during initialization", e);
            Toast.makeText(this, "An error occurred during initialization.", Toast.LENGTH_SHORT).show();
        }
    }

    // Login user with Firebase Authentication
    private void loginUser(final String email, final String password) {
        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        String userEmail = auth.getCurrentUser().getEmail();
                        greetingTextView.setText("Welcome, " + userEmail + "!");
                        greetingTextView.setVisibility(View.VISIBLE);
                        Log.d("FirebaseLogin", "User logged in: " + userEmail);
                        Toast.makeText(MainActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.e("FirebaseLogin", "Login failed: " + task.getException().getMessage());
                        Toast.makeText(MainActivity.this, "Login failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // Register a new user with Firebase Authentication
    private void registerUser(final String email, final String password) {
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        String userEmail = auth.getCurrentUser().getEmail();
                        Log.d("FirebaseRegister", "User registered: " + userEmail);
                        saveUserToDatabase(auth.getCurrentUser().getUid(), email);
                        Toast.makeText(MainActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.e("FirebaseRegister", "Registration failed: " + task.getException().getMessage());
                        Toast.makeText(MainActivity.this, "Registration failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // Save user information to Firebase Realtime Database
    private void saveUserToDatabase(String uid, String email) {
        if (uid == null) return;

        DatabaseReference userRef = database.child("users").child(uid);
        userRef.child("uid").setValue(uid);
        userRef.child("email").setValue(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Log.d("FirebaseDatabase", "User data saved to database.");
                    } else {
                        Log.e("FirebaseDatabase", "Failed to save user data: " + task.getException().getMessage());
                    }
                });
    }
}
