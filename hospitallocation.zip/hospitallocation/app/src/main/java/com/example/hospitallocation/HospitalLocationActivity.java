package com.example.hospitallocation;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.hospitallocation.databinding.ActivityHospitalBinding;

import java.util.Vector;

public class HospitalLocationActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final int FINE_PERMISSION_CODE = 1;
    private GoogleMap mMap;
    private Location currentLocation;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private ActivityHospitalBinding binding;

    private Vector<MarkerOptions> markerOptions;
    private LatLng centerlocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityHospitalBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        // Check and request location permission
        checkAndRequestPermissions();

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        centerlocation = new LatLng(4.001620681287662, 102.1400710256236);

        markerOptions = new Vector<>();

        // Add hospital markers
        markerOptions.add(new MarkerOptions().title("Hospital Kajang")
                .position(new LatLng(2.9931321386486704, 101.79286725423259))
                .snippet("Open during MCO: 24 hours"));

        markerOptions.add(new MarkerOptions().title("Hospital Kangar")
                .position(new LatLng(6.443474024755914, 100.19126910025813))
                .snippet("Open during MCO: 24 hours"));

        markerOptions.add(new MarkerOptions().title("Hospital Kuala Lumpur")
                .position(new LatLng(3.176414595422977, 101.70247605589678))
                .snippet("Open during MCO: 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Ampang")
                .position(new LatLng(3.1311634844646354, 101.76358745028604))
                .snippet("Open during MCO: 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Sultan Abdul Halim,Sungai Petani")
                .position(new LatLng(3.1311634844646354, 101.76358745028604))
                .snippet("Open during MCO: 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Alor Setar")
                .position(new LatLng(6.142013306091082, 100.37097549667568))
                .snippet("Open during MCO: 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Pulau Pinang")
                .position(new LatLng(5.416825709960067, 100.31103836783751))
                .snippet("Open during MCO: 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Raja Permaisuri Bainun, Ipoh")
                .position(new LatLng(4.606259852566788, 101.0902030280264))
                .snippet("Open during MCO: 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Sungai Siput Perak")
                .position(new LatLng(4.828090367255377, 101.05708578318212))
                .snippet("Open during MCO: 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Besar Pahang")
                .position(new LatLng(3.8355133029694826, 103.30494248318124))
                .snippet("Open during MCO: 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Sultanah Nur Zahirah, Terengganu")
                .position(new LatLng(5.324795964381382, 103.14977508132803))
                .snippet("Open during MCO: 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Besut")
                .position(new LatLng(5.729789073894023, 102.49253771016538))
                .snippet("Open during MCO: 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Universiti Sains Malaysia (HUSM), Kubang Kerian")
                .position(new LatLng(5.308836, 102.285973))
                .snippet("Open 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Raja Perempuan Zainab II, Kota Bharu")
                .position(new LatLng(6.099900, 102.280300))
                .snippet("Open 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("POLIKLINIK MAYA 24 JAM @ KLINIK - PENGKALAN CHEPA")
                .position(new LatLng(6.112223, 102.319911))
                .snippet("Open 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Kota Bharu Medical Center, Kelantan")
                .position(new LatLng(6.105160, 102.259786))
                .snippet("Open 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Tumpat, Kelantan")
                .position(new LatLng(6.189720, 102.157326))
                .snippet("Open 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Tanah Merah, Kelantan")
                .position(new LatLng(5.810011, 102.152357))
                .snippet("Open 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Gua Musang, Kelantan")
                .position(new LatLng(4.860233, 101.954892))
                .snippet("Open 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Hospital Machang, Kelantan")
                .position(new LatLng(5.763145, 102.225821))
                .snippet("Open 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Klinik Baru Machang, Kelantan")
                .position(new LatLng(5.764162, 102.218777))
                .snippet("Open 24 hours")
        );

        markerOptions.add(new MarkerOptions().title("Klinik Kota Harmoni, Machang, Kelantan")
                .position(new LatLng(5.776816, 102.213705))
                .snippet("Open 24 hours")
        );
    }

    private void checkAndRequestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, FINE_PERMISSION_CODE);
        }
    }

    @SuppressLint("MissingPermission")
    private void getLastLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationProviderClient.getLastLocation()
                    .addOnSuccessListener(this, location -> {
                        if (location != null) {
                            currentLocation = location;

                            // Move camera to the current location
                            LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15)); // Zoom level 15
                        } else {
                            // Handle case where location is null (e.g., set a default location)
                            LatLng defaultLocation = new LatLng(4.001620681287662, 102.1400710256236); // Example: Malaysia
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 8));
                        }
                    })
                    .addOnFailureListener(e -> {
                        // Log or handle failure to retrieve location
                        e.printStackTrace();
                    });
        } else {
            // Request location permissions if not already granted
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, FINE_PERMISSION_CODE);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add hospital markers
        for (MarkerOptions mark : markerOptions) {
            mMap.addMarker(mark);
        }

        // Enable "My Location" button and current location marker
        enableMyLocation();

        // Center camera on hospitals
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(centerlocation, 10));

        // Get the user's current location
        getLastLocation();
    }

    /**
     * Enables the My Location layer if the fine location permission has been granted.
     */
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            if (mMap != null) {
                mMap.setMyLocationEnabled(true);
            }
        } else {
            String[] perms = {Manifest.permission.ACCESS_FINE_LOCATION};
            // Request location permission
            ActivityCompat.requestPermissions(this, perms, FINE_PERMISSION_CODE);
        }
    }
}
