package com.example.hospitallocation;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private TextView tvWelcomeMessage;
    private Button btnAboutUs, btnHospitalLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Get the email passed from LoginActivity or AboutUsActivity
        String userEmail = getIntent().getStringExtra("userEmail");

        // Initialize views and display a welcome message with the user's email
        tvWelcomeMessage = findViewById(R.id.tvWelcomeMessage);
        if (userEmail != null) {
            tvWelcomeMessage.setText("Welcome, " + userEmail);  // Display user email or modify as needed
        } else {
            tvWelcomeMessage.setText("Welcome, User!");  // Default message if no email is passed
        }

        // Initialize buttons
        btnAboutUs = findViewById(R.id.btnAboutUs);
        btnHospitalLocation = findViewById(R.id.btnHospitalLocation);

        // Set onClick listeners for the buttons
        btnAboutUs.setOnClickListener(view -> {
            // Open About Us Activity and pass user email
            Intent aboutUsIntent = new Intent(HomeActivity.this, AboutUsActivity.class);
            aboutUsIntent.putExtra("userEmail", userEmail);  // Pass the email to AboutUsActivity
            startActivity(aboutUsIntent);
        });

        btnHospitalLocation.setOnClickListener(view -> {
            // Open Hospital Location Activity
            Intent hospitalLocationIntent = new Intent(HomeActivity.this, HospitalLocationActivity.class);
            startActivity(hospitalLocationIntent);
        });
    }
}
